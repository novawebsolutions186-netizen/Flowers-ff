# A Little Flower, A Lot of Love 🌹

A responsive romantic flower animation built with plain HTML, CSS and JavaScript. No build tools or dependencies are required.

## Preview locally
Open `index.html` in any modern browser.

## Publish with GitHub Pages
1. Sign in to GitHub and create a **public** repository named `flower-love-site`.
2. Upload `index.html` and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**, choose `main` and `/(root)`, then Save.
5. After the deployment finishes, the public site should be at `https://YOUR-GITHUB-USERNAME.github.io/flower-love-site/`.

## Personalize
Edit the text inside the `<section class="letter" ...>` in `index.html`. The site is static and does not collect or send any personal data.
